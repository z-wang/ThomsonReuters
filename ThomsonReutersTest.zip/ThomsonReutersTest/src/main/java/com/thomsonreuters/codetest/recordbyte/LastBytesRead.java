package com.thomsonreuters.codetest.recordbyte;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;

public class LastBytesRead implements ILastBytesRead {
    private ArrayList<Byte> bytes = new ArrayList<>();
    private volatile int count = 0;
    private int size = 1024; //count put into constructor for size changing.
    private Semaphore writeSem, readSem, countSem;

    public LastBytesRead() {
        writeSem = new Semaphore(1, true);
        readSem = new Semaphore(1, true);
        countSem = new Semaphore(1, true);
    }

    @Override
    public void recordByte(byte b) {
        try {
            writeSem.acquire();
            countSem.acquire();
        } catch (InterruptedException e) {
            //log the error
            System.out.println(e);
            return;
        }

        bytes.add(b);
        count++;

        writeSem.release();
        countSem.release();
    }

    @Override
    public synchronized String printLastBytes() {
        try {
            readSem.acquire();
            countSem.acquire();
        } catch (InterruptedException e) {
            //log the error
            System.out.println(e);
            return "";
        }

        StringBuffer sb = new StringBuffer();
        int readCount = size;
        if (count < size) {
            readCount = count;
        }
        for (int i = count - readCount; i < count; i++) {
            sb.append(bytes.get(i));
        }

        readSem.release();
        countSem.release();
        return sb.toString();
    }
}
