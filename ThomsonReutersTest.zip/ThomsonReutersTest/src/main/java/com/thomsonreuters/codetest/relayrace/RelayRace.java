package com.thomsonreuters.codetest.relayrace;

import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class RelayRace implements IRelayRace {
    private HashMap<Team, Double> teamMap = new HashMap<>();
    private double lowerBoundTime = 9.0, upperBoundTime = 10.5;

    public RelayRace(Team[] teams) {
        for (int i = 0; i < teams.length; i++) {
            teamMap.put(teams[i], 0d);
        }
    }

    @Override
    public void startRace() {
        List<Team> keys = new ArrayList<>(teamMap.keySet());
        double sum;
        for (Team team : keys) {
            sum = 0d;
            for (int i = 0; i < team.getRunnerNum(); i++) {
                sum += ThreadLocalRandom.current().nextDouble(lowerBoundTime, upperBoundTime);
            }
            teamMap.put(team, sum);
        }
        display();
    }

    //use for displaying result, can be called from startRace or in a separate call
    public void display() {
        List<Team> sortedList = new ArrayList<>(teamMap.keySet());
        Collections.sort(sortedList, (a,b) -> teamMap.get(a).compareTo(teamMap.get(b)));
        DecimalFormat df = new DecimalFormat("#.###");

        int rank = 1;
        for (Team team : sortedList) {
            System.out.println(order(rank) + " " + team.getName() + " - " + df.format(teamMap.get(team)));
            rank++;
        }
    }

    //order helper, convert 1 to 1st, 2 to 2nd
    public static String order(int i) {
        String[] suffix = { "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th" };
        switch (i % 100) {
            case 11:
            case 12:
            case 13:
                return i + "th";
            default:
                return i + suffix[i % 10];
        }
    }
}
