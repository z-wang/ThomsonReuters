package com.thomsonreuters.codetest.relayrace;

/**
 * Created by zihanwang on 4/30/16.
 */
public interface IRelayRace {
    public abstract void startRace();
}
