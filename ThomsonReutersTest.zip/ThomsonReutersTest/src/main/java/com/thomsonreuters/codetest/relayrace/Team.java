package com.thomsonreuters.codetest.relayrace;

public class Team {
    private int runnerNum;
    private String name;

    public Team(String name, int runnerNum) {
        this.name = name;
        this.runnerNum = runnerNum;
    }

    public int getRunnerNum() {
        return runnerNum;
    }

    public String getName() {
        return name;
    }

    public void setRunnerNum(int runnerNum) {
        this.runnerNum = runnerNum;
    }

    public void setName(String name) {
        this.name = name;
    }
}
