package com.thomsonreuters.codetest.recordbyte;

/**
 * Created by zihanwang on 4/30/16.
 */
public interface ILastBytesRead {
    public abstract void recordByte(byte b);
    public abstract String printLastBytes();
}
