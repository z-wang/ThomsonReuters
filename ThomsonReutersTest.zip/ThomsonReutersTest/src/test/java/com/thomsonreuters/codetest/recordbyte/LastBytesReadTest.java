package com.thomsonreuters.codetest.recordbyte;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LastBytesReadTest {
    private static String fastWriteQuery(LastBytesRead read, int repeat) {
        int i = 0;
        System.out.println("fast write start");
        while (i < repeat - 1) {
            read.recordByte((byte) 1);
            i++;
        }
        System.out.println("fast write done");

        return read.printLastBytes();
    }

    private static String regularWriteQuery(LastBytesRead read, int repeat) throws InterruptedException {
        int i = 0;
        System.out.println("regular write start");
        while (i < repeat - 1) {
            read.recordByte((byte) 1);
            Thread.sleep(5);
            i++;
        }
        System.out.println("regular write done");

        return read.printLastBytes();
    }

    private static String slowWriteQuery(LastBytesRead read, int repeat) throws InterruptedException {
        int i = 0;
        System.out.println("slow write start");
        while (i < repeat - 1) {
            Thread.sleep(10);
            read.recordByte((byte) 1);
            i++;
        }
        System.out.println("slow write done");

        return read.printLastBytes();
    }

    @Test
    public void TypeReadTest() throws InterruptedException {
        LastBytesRead read = new LastBytesRead();

        //given enough thread pool, on the multi core computer, finish order should be fast -> slow -> regular
        ExecutorService executor = Executors.newFixedThreadPool(10);
        List<Callable<String>> callables = Arrays.asList(
                () -> fastWriteQuery(read, 100),
                () -> regularWriteQuery(read, 900),
                () -> slowWriteQuery(read, 100)
        );

        executor.invokeAll(callables)
                .stream()
                .map(future -> {
                    try {
                        return future.get();
                    }
                    catch (Exception e) {
                        throw new IllegalStateException(e);
                    }
                }).forEach( i -> System.out.println(i.length()));
        //using streaming printing, the size for fast and slow should be smaller than 1024 while regular should be 1024.
        //print out number can be (not necessary) :
        //100 (almost always)
        //1024 (always)
        //390 (around this number)
    }
}
