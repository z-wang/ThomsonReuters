package com.thomsonreuters.codetest.relayrace;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class RelayRaceTest {
    @Test
    public void RaceTest() {
        Team[] teams = {
                new Team("Team 1", 4),
                new Team("Team 2", 4),
                new Team("Team 3", 4),
                new Team("Team 4", 4),
                new Team("Team 5", 4),
                new Team("Team 6", 4)
        };

        RelayRace race = new RelayRace(teams);
        assertEquals(RelayRace.order(1), "1st");
        assertEquals(RelayRace.order(2), "2nd");
        assertEquals(RelayRace.order(3), "3rd");
        assertEquals(RelayRace.order(4), "4th");

        race.startRace();    //print race results.
    }
}
